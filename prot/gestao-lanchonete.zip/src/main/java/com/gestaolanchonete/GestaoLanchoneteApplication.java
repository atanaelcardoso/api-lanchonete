package com.gestaolanchonete;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestaoLanchoneteApplication {
    public static void main(String[] args) {
        SpringApplication.run(GestaoLanchoneteApplication.class, args);
    }
}
